#!/bin/sh
make -f makefile.std
sh png2pnm.sh
sh pnm2png.sh

